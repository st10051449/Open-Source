package com.example.timeglimpse

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CurrentTasksActivity : AppCompatActivity() {

    private val taskList = mutableListOf<Task>()

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TaskAdapter
    private lateinit var layoutManager: LinearLayoutManager
    companion object {const val ADD_TASK_REQUEST_CODE = 1}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_current_tasks)

        recyclerView = findViewById(R.id.lv_taskList)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = TaskAdapter(taskList){ task ->
            // Handle item click, open activity or dialog to edit task details
            Toast.makeText(this, "Clicked: ${task.date}", Toast.LENGTH_SHORT).show()
        }

        recyclerView.adapter = adapter

        val btnEditTask: Button = findViewById(R.id.btnEditTask)
        btnEditTask.setOnClickListener {
            // Handle edit button click
            Toast.makeText(this, "Edit button clicked", Toast.LENGTH_SHORT).show()
        }

        val btnAddTask: Button = findViewById(R.id.btnAddTask)
        btnAddTask.setOnClickListener{
            startActivity(Intent(this, TimesheetEntry::class.java))
        }
    }

    // Handle the result from TimesheetEntry activity
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)


        if (requestCode == ADD_TASK_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            // Get data from the returned Intent
            val date = data?.getStringExtra("date")
            val startTime = data?.getStringExtra("startTime")
            val endTime = data?.getStringExtra("endTime")
            val description = data?.getStringExtra("description")
            val category = data?.getStringExtra("category")

            // Create a new Task object with the retrieved data
            val newTask = Task(date.toString(), startTime.toString(),
                endTime.toString(), description.toString(), category.toString()
            )

            // Add the new task to the taskList
            taskList.add(newTask)

            // Notify the adapter that the data set has changed
            adapter.notifyDataSetChanged()

            // Optionally, you can save the new task to your data storage mechanism (e.g., database)
        }
    }
}