package com.example.timeglimpse

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(private val taskList: List<Task>, private val onItemClick: (Task) -> Unit) :
    RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.one_line_task, parent, false)
        val holder = TaskViewHolder(view)
        return holder
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = taskList[position]
        holder.bind(task)
    }

    override fun getItemCount(): Int {
        return taskList.size
    }

    inner class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val dateTextView: TextView = itemView.findViewById(R.id.txtDate)
        private val startTimeTextView: TextView = itemView.findViewById(R.id.txtStartTime)
        private val endTimeTextView: TextView = itemView.findViewById(R.id.txtEndTime)
        private val descriptionTextView: TextView = itemView.findViewById(R.id.txtDescription)
        private val categoryTextView: TextView = itemView.findViewById(R.id.txtCategory)

        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val task = taskList[position]
                    onItemClick(task)
                }
            }
        }

        fun bind(task: Task) {
            this.dateTextView.text = task.date
            this.startTimeTextView.text = task.startTime
            this.endTimeTextView.text = task.endTime
            this.descriptionTextView.text = task.description
            this.categoryTextView.text = task.category

        }
    }
}


