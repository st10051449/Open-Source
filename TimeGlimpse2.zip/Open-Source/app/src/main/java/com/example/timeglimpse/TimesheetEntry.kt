package com.example.timeglimpse

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class TimesheetEntry : AppCompatActivity() {
    private lateinit var txtDate: EditText
    private lateinit var txtStartTime: EditText
    private lateinit var txtEndTime: EditText
    private lateinit var txtDescription: EditText
    private lateinit var txtCategory: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timesheet_entry)

        // Initialize views
        btnSave.setOnClickListener {
            // Get data from EditText fields
            val date = txtDate.text.toString()
            val startTime = txtStartTime.text.toString()
            val endTime = txtEndTime.text.toString()
            val description = txtDescription.text.toString()
            val category = txtCategory.text.toString()

            // Pass data back to CurrentTasksActivity
            val intent = Intent()
            intent.putExtra("date", date)
            intent.putExtra("startTime", startTime)
            intent.putExtra("endTime", endTime)
            intent.putExtra("description", description)
            intent.putExtra("category", category)
            setResult(Activity.RESULT_OK, intent)
            finish()
        }


    }
}
