package com.example.timeglimpse

 class Task(
    var date: String,
    var startTime: String,
    var endTime: String,
    var description: String,
    var category: String
    // Add more fields as needed
)